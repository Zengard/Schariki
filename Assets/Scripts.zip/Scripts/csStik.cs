using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class csStik : MonoBehaviour
{
    [SerializeField] GameObject zentr_stika;

    public void Stik_naschat()
    {
        if (GUI.RepeatButton(new Rect(25, 25, 100, 30), "RepeatButton"))
        {
            Debug.Log(12345);
            transform.position = Input.mousePosition;
        }
    }

}
